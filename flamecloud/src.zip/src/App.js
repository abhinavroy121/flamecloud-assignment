import logo from './logo.svg';
import './App.css';
import Action from './components/Action';

function App() {
  return (
    <div className="App">
      <Action/>
    </div>
  );
}

export default App;
